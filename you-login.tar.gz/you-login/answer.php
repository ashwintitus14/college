<?php
include('data.php');

echo $email;

?>

<?php
include('data.php');
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "defuse";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// ---------------------------------------------------------------------------//


$email =  $_POST['email'];

$sql = "SELECT * FROM users WHERE email = '$email';";
$result = $conn->query($sql);

// echo $sql;

echo $email;

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Name: " . $row["name"]. " " . $row["email"]. "<br>";
    }
} else {
    echo "0 results";
}
//
// if ($conn->query($sql) === TRUE) {
//     // echo "New record created successfully";
//     header("Location: http://localhost/p2.html");
// } else {
//     // echo "Error: " . $sql . "<br>" . $conn->error;
//     echo "Login Error: Contact Admin";
// }

$conn->close();


?>
